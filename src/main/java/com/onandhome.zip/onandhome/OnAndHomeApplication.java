package com.onandhome;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnAndHomeApplication {

    public static void main(String[] args) {
        SpringApplication.run(OnAndHomeApplication.class, args);
    }

}

